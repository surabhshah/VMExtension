
var net = require('net');
const nmea = require('node-nmea');
var AuthenticationContext = require('adal-node').AuthenticationContext;
var request = require('request');
var fs = require('fs');
var jsonfile = require('jsonfile');
var AzureAdaptor = require('./AzureAdaptor');
var AzureAdaptorInstance = new AzureAdaptor();
var config = require('./config');
var authorityUrl = config.AdAuthorityHostUrl + '/' + config.AdTenantName;
var context = new AuthenticationContext(authorityUrl);
var bus = require('./eventbus');
var sensorListFile = 'sensorlist.json';
var SensorTypesFile = 'sensorTypes.json';
var IsAzureClientConnected = false;
var AdResponse, sensorList, sensorTypeList;
console.log(config);
process.env.port = 9999;
console.log("Port ", process.env.port)

/**
 * Fucntion to login Ad silently
 */
context.acquireTokenWithClientCredentials(config.AdResource, config.AdApplicationId, config.AdClientSecret, function (err, tokenResponse) {
    if (err) {
        console.log('well that didn\'t work: ' + err.stack);
    } else {
        AdResponse = tokenResponse;
        console.log("Info :: Ad Authenticated");
        getConnectionString(config.DeviceName);
      
    }
});

function getConnectionString(deviceName) {
    if (AdResponse.accessToken) {
        var headers = {
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ' + AdResponse.accessToken
            //'Authorization': 'Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsIng1dCI6IlNTUWRoSTFjS3ZoUUVEU0p4RTJnR1lzNDBRMCIsImtpZCI6IlNTUWRoSTFjS3ZoUUVEU0p4RTJnR1lzNDBRMCJ9.eyJhdWQiOiI5MWJkNzUzNC03OTI3LTQ4YTctYTc4MC1mYmIxNWNjMDk5NDAiLCJpc3MiOiJodHRwczovL3N0cy53aW5kb3dzLm5ldC9hNzc3MjAxZC03NmY2LTQxOGQtYTAwNi03NTc1Mzc3MTVhYWUvIiwiaWF0IjoxNTIwNTg2MDU4LCJuYmYiOjE1MjA1ODYwNTgsImV4cCI6MTUyMDU4OTk1OCwiYWlvIjoiQVNRQTIvOEdBQUFBVFY3ank0c1J2dldabm1EWGYrQ05LZkxibzBzZmJkUVFFNnlubnJrelVuaz0iLCJhbXIiOlsicHdkIl0sImlwYWRkciI6IjExNC4xNDMuNi45OCIsIm5hbWUiOiJKYXllc2ggTHVua2FkIiwibm9uY2UiOiI3Mzg2MzQ2OS05NGY5LTRhMDAtYjZlYS00MThhYWFkODkwMzUiLCJvaWQiOiJiZTU5NmY0Zi0xODk2LTQyYzAtOWNkMS00NzQyMzM4OGJjNTIiLCJzdWIiOiJna2Jya0o2RWFRUzBtNUE4ZDlBX0g3OVdoV280Y0NvZF9sSFVkdnpRT2lFIiwidGlkIjoiYTc3NzIwMWQtNzZmNi00MThkLWEwMDYtNzU3NTM3NzE1YWFlIiwidW5pcXVlX25hbWUiOiJqYXllc2hAbXNpb3RvdXRsb29rLm9ubWljcm9zb2Z0LmNvbSIsInVwbiI6ImpheWVzaEBtc2lvdG91dGxvb2sub25taWNyb3NvZnQuY29tIiwidXRpIjoibjNFMUtTaEdvMGlBblhvVDlrNEdBQSIsInZlciI6IjEuMCJ9.Sly3sd-NWfqnTFbfpsFRQdGFcJATTrhxZMFkpG7hULpyu5UZISpn1vS6kK-dEVUYLsRoedMtDZ4GHTyFvnkbDdvVaJvQ1cRbRZeM7knTl2DLJ6OJVVoWrGYYxutbcsMl9x8B1cRSe7oeYwq6VK86eA12Hp9nCmyilB9krF2O61m7ScZOdcvKZbIO77pVbkfsqdXevzixko4be3S5MROqIhNeqV7b2wwAFiFM09Rjl1lQhYeMAeNk2xPKG_2Q5_Xt8rPJOL9BFamKajpA32cGcd_vUjQfCWKJkaXxA7vEWfn0yID6nHyRYQSMTJAHBAYAuWaj2TtU5fJfGBJLOQQqLA&state=0a4c2209-3905-4d10-a2f3-8849efbc9182&session_state=d18be84a-4221-4d12-9a9a-d776acbf8ba8'
        }


        // Configure the request
        var options = {
            url: config.RestServer + 'api/IotHubGateway',
            method: 'POST',
            headers: headers,
            body: '"' + deviceName + '"'
        }

        // Start the request
        request(options, function (error, response, body) {

            if (!error) {
                response.body = JSON.parse(response.body);
                if (response.statusCode == 200) {
                    AzureAdaptorInstance.AzureInit(response.body.DeviceConnectionString, function () {
                        IsAzureClientConnected = true;
                    });
                } else {
                    console.log("Connection String Response ::",response.body);
                }
            } else {
                console.log("Error: ", error);
            }
        })
    }
    else {
        console.log("Error :: Ad Token not present");
    }
}




var server = net.createServer(function (socket) {
    //console.log("Socket Connected ::", socket);
    // Handle incoming messages from clients.
    socket.on('data', function (data) {
        console.log("Data", data.toString('utf8'));
        //data=data.toString().replaceAll('\r\n',',')
        data = data.toString().split('\r\n').join(',');
        //console.log("Data",data);
        var arr = data.split(",");
        //console.log(arr);
        var gprmc = arr.slice(15, 30).join(",")
        // console.log(gprmc);
        const decodedNmea = nmea.parse(gprmc)

        if (decodedNmea.valid && IsAzureClientConnected) {
            if (sensorList&&sensorList.hasOwnProperty(arr[0])) {
                var sensor = sensorList[arr[0]];
                console.log("Sensor ::", sensor);
                if (sensorTypeList.hasOwnProperty(sensor.SensorType)) {
                    var sensorType = sensorTypeList[sensor.SensorType];
                    var d = new Date();
                    var obj =
                        {
                            "SensorKey": sensor.SensorKey,
                            "GroupId": sensor.GroupId,
                            "Timestamp": d.toISOString(),
                            "CapabilityId": sensorType.SensorCapabilities[0].Id,
                            "Latitude": decodedNmea.loc.geojson.coordinates[1],
                            "Longitude": decodedNmea.loc.geojson.coordinates[0],
                            "AssetBarcode": sensor.AssetBarcode
                        }
                    console.log("Obj", obj);
                    AzureAdaptorInstance.AzureHandle(obj);
                }
                else {
                    console.log("Error :: " + sensor.SensorType + " not present");
                }

            }
            else {
                console.log("Error :: " + arr[0] + " not whitelisted");
            }

        }
        else {
            console.log("Error :: Azure Client not connected /invalid co-ordinates");
        }

    });

});
bus.on('updatelist', function () {
    updateSensorList();
});
bus.on('updateSensorTypes', function () {
    updateSensorTypeList();
});
function updateSensorList() {
    if (fs.existsSync(sensorListFile)) {
        sensorList = jsonfile.readFileSync(sensorListFile, "utf8");
        console.log(sensorList);
    }
}
function updateSensorTypeList() {
    if (fs.existsSync(SensorTypesFile)) {
        sensorTypeList = jsonfile.readFileSync(SensorTypesFile, "utf8");
        console.log(sensorTypeList);
    }
}

server.listen(9999);