//Environment Variables
// process.env['CUSTOMCONNSTR_AdResource'] = "https://msiotoutlook.onmicrosoft.com/1c824300-190c-4663-88d7-5d1cde815c2b";
// process.env['CUSTOMCONNSTR_AdApplicationId'] = "2f5dbaee-de36-4a1f-bf41-2467710bd11e";
// process.env['CUSTOMCONNSTR_AdClientSecret'] = "E2pO+L1T+1hx9EcBBKpMOfdvD9d6eX8H7UOjal1jpXA=";
// process.env['CUSTOMCONNSTR_AdTenantName'] = "msiotoutlook.onmicrosoft.com";
// process.env['CUSTOMCONNSTR_DeviceName'] = "SynnexGPSGateway";
// process.env['CUSTOMCONNSTR_RestServer'] = "https://assetSynnexAPIServ.azurewebsites.net/";

var Userconfig = {
  
    AdResource: process.env.CUSTOMCONNSTR_AdResource,
    AdApplicationId: process.env.CUSTOMCONNSTR_AdApplicationId,
    AdClientSecret: process.env.CUSTOMCONNSTR_AdClientSecret,
    DeviceName: process.env.CUSTOMCONNSTR_DeviceName,
    RestServer: process.env.CUSTOMCONNSTR_RestServer,
    AdTenantName: process.env.CUSTOMCONNSTR_AdTenantName,
    AdAuthorityHostUrl:'https://login.windows.net',
    AzureReconnectionInterval: 60000,


};
module.exports = Userconfig;

