//Environment Variables

process.env['CUSTOMCONNSTR_DeviceName'] = "SynnexGPSGateway";
//process.env['CUSTOMCONNSTR_RestServer'] = "https://atsnxv3restapp.azurewebsites.net/";
//process.env['CUSTOMCONNSTR_ConnectionString'] = 'Server = tcp: sqlserveredldfkdkbgqya.database.windows.net; initial catalog = atdb; persist security info = False; user id = adminuser; password = Mobiliya!@#$; MultipleActiveResultSets = True; Encrypt = True; TrustServerCertificate = False;'

var Userconfig = {  
   
    DeviceName: process.env.CUSTOMCONNSTR_DeviceName,
    RestServer: process.env.CUSTOMCONNSTR_RestServer,
    ConnectionString: process.env['CUSTOMCONNSTR_ConnectionString'],
    AdAuthorityHostUrl:'https://login.windows.net',
    AzureReconnectionInterval: 60000,


};
module.exports = Userconfig;

