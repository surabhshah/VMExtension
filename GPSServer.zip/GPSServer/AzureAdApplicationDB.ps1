
param (
    [Parameter(Mandatory=$true)][string]$userId ,
    [Parameter(Mandatory=$true)][string]$userPassword,
    [Parameter(Mandatory=$true)][string]$replyUrls,
	[Parameter(Mandatory=$true)][string]$sqlConnectionString
 )

Install-PackageProvider -Name NuGet -MinimumVersion 2.8.5.201 -Force 
 # AzureAD module required to run Azure AD command.
 Install-Module AzureAD -Force


 
# Get tenant from user id.
$startIndex =  $userId.LastIndexOf('@') +1
$length = $userId.Length - $startIndex
$tenant = $userId.SubString($startIndex, $length)


# Application name
$displayName = "SynnexAD"+ [guid]::NewGuid()

# Web application URL
$identifierUris = $replyUrls + [guid]::NewGuid()

$password = ConvertTo-SecureString $userPassword  -AsPlainText -Force
$Cred =  New-Object System.Management.Automation.PSCredential ($userId, $password)

# connecting to azure
Connect-AzureAD -Credential $Cred 

# Azure AD application secrete
$psadCredential = New-Object Microsoft.Open.AzureAD.Model.PasswordCredential
$psadCredential.StartDate = Get-Date
$psadCredential.EndDate = $psadCredential.StartDate.AddYears(1000)
$psadCredential.Value = [guid]::NewGuid()

# Create a .NET Generics List of RequiredResourceAccess
$requiredResources = [System.Collections.Generic.List[Microsoft.Open.AzureAD.Model.RequiredResourceAccess]]::New()

# Retrieve the AAD SPN and AAD Read and Sign-in Permissions info
$aad_spn = Get-AzureADServicePrincipal -Filter "DisplayName eq 'Microsoft.Azure.ActiveDirectory'"
$aad_Oauth2_readAndSignInPerm = $aad_spn | select -expand Oauth2Permissions | ? {$_.value -eq "User.Read"}

# Create ResourceAccess object representing Read and Sign-in Permission
$aad_readAndSignInPerm = [Microsoft.Open.AzureAD.Model.ResourceAccess]::New()
$aad_readAndSignInPerm.Id = $aad_Oauth2_readAndSignInPerm.Id
$aad_readAndSignInPerm.Type = "Scope"

# Create RequiredResourceAccess object representing Read and Sign-In Permission on AAD
$aad_ResourceAccess = [Microsoft.Open.AzureAD.Model.RequiredResourceAccess]::New()
$aad_ResourceAccess.ResourceAppId = $aad_spn.AppId
$aad_ResourceAccess.ResourceAccess = $aad_readAndSignInPerm

$requiredResources.Add($aad_ResourceAccess)

# Create the Azure AD application	
$azureADApp = New-AzureADApplication -DisplayName $displayName -IdentifierUris $identifierUris -ReplyUrls $replyUrls -Oauth2AllowImplicitFlow $true -PasswordCredentials $psadCredential   -RequiredResourceAccess $requiredResources

$filEName = 'C:\gpsServer\GPSServer\AAD.txt'
$azureADApp.AppId > $filEName 
$psadCredential.Value >> $filEName 
$tenant >> $filEName 

# Adding Application Id to database
$sqlConnection = New-Object System.Data.SqlClient.SqlConnection
$sqlConnection.ConnectionString = $sqlConnectionString

$sqlConnection.Open()

$sqlCommand = New-Object System.Data.SqlClient.SqlCommand

$sqlCommand.Connection = $sqlConnection

$sqlCommand.CommandText = "BEGIN
INSERT INTO [dbo].[ApplicationConfigurationEntries]  ([ConfigurationKey],  [ConfigurationValue], [ApplicationConfigurationId])
SELECT 'AppId', '" + $azureADApp.AppId + "',  Id FROM [dbo].[ApplicationConfigurations]
WHERE ConfigurationType = 'AzureAD'  
END"

$sqlCommand.ExecuteScalar()
	
Read-Host -Prompt �Press Enter to exit�
